<!-- PORTFOLIO SECTION START -->
<section class="portfolio-section" id="works-section">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="section-header text-center">
                    <h2 class="section-title wow fadeInUp" data-wow-delay=".3s">
                        پروژه های اخیر
                    </h2>
                    <p class="wow fadeInUp" data-wow-delay=".4s">
                        ما تلاش کرده‌ایم تا با ترکیبی از خلاقیت و تخصص، نتایج بی‌نظیری برای مشتریان خود به ارمغان بیاوریم. <br>
                         با همکاری نزدیک و تمرکز بر جزئیات، پروژه‌های موفق و منحصر به فردی را به سرانجام رسانده‌ایم  .
                    </p>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <div
                    class="portfolio-filter text-center wow fadeInUp"
                    data-wow-delay=".5s"
                ></div>

                <div class="portfolio-box wow fadeInUp" data-wow-delay=".6s">
                    <?php $__currentLoopData = $Projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="portfolio-sizer"></div>
                    <div class="gutter-sizer"></div>
                    <div class="portfolio-item branding">
                        <div class="image-box">
                            <img
                                src="assets/img/portfolio/<?php echo e($Project['image']); ?>"
                                alt=""
                            />
                        </div>
                        <div class="content-box">
                            <h3 class="portfolio-title">
                                <?php echo e($Project['proname']); ?>

                            </h3>
                            <p><?php echo e($Project['paragraph']); ?></p>
                            <i class="flaticon-up-right-arrow"></i>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- PORTFOLIO SECTION END -->
<?php /**PATH C:\Users\NOURI_Abolfazl\Desktop\Resome-Page\resources\views/layout/main/portfolio.blade.php ENDPATH**/ ?>