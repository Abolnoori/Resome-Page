
@extends('layout.Master')
@section('title' ,  $title )
@section('email' ,  $email )
@section('name' ,  $name )
@section('job-1' , $job1)
@section('job-2' , $job2)
@section('aboutmy' , $aboutmy)
@section('link_resome' , $links['resome'])
@section('link_telegram' , $links['telegram'])
@section('link_instagram' , $links['instagram'])
@section('link_linkedin' , $links['linkedin'])
@section('link_github' , $links['github'])
{{-- اعداد برعکس وارد شود 
مثلا :: 
بیست و یک = 12 در اول و آخر آن صفر نباشد --}}
@section('counters_hostory' , $counters['hostory'])
@section('counters_completion' , $counters['completion'])
@section('counters_satisfied' , $counters['satisfied'])
@section('counters_experience' , $counters['experience'])


          

                  





