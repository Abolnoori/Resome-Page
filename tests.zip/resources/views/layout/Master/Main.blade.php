    <main class="site-content" id="content">
      
      @include('layout.main.hero')
      @include('layout.main.services')
      @include('layout.main.skills')
      @include('layout.main.resume')
      @include('layout.main.portfolio')
      @include('layout.main.testimonial')
      @include('layout.main.contact')

    </main>