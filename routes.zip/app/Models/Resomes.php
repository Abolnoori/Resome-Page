<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Resomes extends Model
{
        protected $fillable = ['user','time','title','institute'];
    
}
