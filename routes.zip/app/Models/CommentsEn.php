<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CommentsEn extends Model
{
        protected $table = 'comments-en';
      
    
}
