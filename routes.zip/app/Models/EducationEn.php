<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class EducationEn extends Model
{
        protected $table = 'education-en';
    
    
}
