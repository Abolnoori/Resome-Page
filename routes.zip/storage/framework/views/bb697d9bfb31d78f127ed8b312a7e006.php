<!-- RESUME SECTION START -->
      <section class="resume-section" id="resume-section">
        <div class="container">
          <div class="row">
            <div class="col-md-6">
              <div class="section-header wow fadeInUp" data-wow-delay=".3s">
                <h2 class="section-title">
                  <i class="flaticon-recommendation"></i> سابقه کاری من
                </h2>
              </div>

              <div class="resume-widget">
                <?php $__currentLoopData = $Resomes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Resome): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  
                <div class="resume-item wow fadeInLeft" data-wow-delay=".4s">
                  <div class="time"> <?php echo e($Resome['time']); ?> </div>
                  <h3 class="resume-title"><?php echo e($Resome['title']); ?></h3>
                  <div class="institute"><?php echo e($Resome['institute']); ?></div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
              </div>
            </div>

            <div class="col-md-6">
              <div class="section-header wow fadeInUp" data-wow-delay=".4s">
                <h2 class="section-title">
                  <i class="flaticon-graduation-cap"></i> تحصیلات من
                </h2>
              </div>

              <div class="resume-widget">
                <?php $__currentLoopData = $Education; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Education): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  
                <div class="resume-item wow fadeInRight" data-wow-delay=".5s">
                  <div class="time"><?php echo e($Education['time']); ?></div>
                  <h3 class="resume-title"><?php echo e($Education['title']); ?></h3>
                  <div class="institute"><?php echo e($Education['institute']); ?></div>
                </div>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!-- RESUME SECTION END --><?php /**PATH C:\Users\NOURI_Abolfazl\Desktop\Resome-Page\resources\views/layout/main/resume.blade.php ENDPATH**/ ?>