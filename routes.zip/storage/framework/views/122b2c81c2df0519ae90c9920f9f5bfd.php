<!DOCTYPE html>
<html lang="fa">
    <head>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <meta http-equiv="X-UA-Compatible" content="ie=edge" />
        <title>Eror - Page Not Found</title>

         <script src="https://cdn.tailwindcss.com"></script>
        <style>
            @font-face {
                font-family: GillSans;
                src: url(assets/fonts/GillSansBold.woff) format("woff");
            }
            * {
                margin: 0px;
                padding: 0px;
                box-sizing: border-box;
                -webkit-user-select: none; /* Safari */
                -ms-user-select: none; /* IE 10 and IE 11 */
                user-select: none;
            }
        </style>
    </head>
    <body class="overflow-hidden">
        <div class="flex mt-[-50px] items-center justify-center gap-2.5 h-screen w-full flex-col font-[GillSans]">
            <div><h1 class="relative text-[22vw] md:text-[15vw] font-bold bg-[url('assets/img/404/Galaxy.jpg')] bg-cover [-webkit-text-fill-color:transparent] [-webkit-background-clip:text] [background-clip:text]">Oops!</h1></div>
            <div><h3 class="font-[''] relative md:mt-5 text-[3.5vw] lg:text-[1.2vw] md:text-[2vw] tracking-[1.8px]">404 - Page <?php echo e($name); ?> Not Found</h3></div>
            
            
            
        </div>
    </body> 
</html>

<?php /**PATH C:\Users\NOURI_Abolfazl\Desktop\Resome-Page\resources\views/404.blade.php ENDPATH**/ ?>