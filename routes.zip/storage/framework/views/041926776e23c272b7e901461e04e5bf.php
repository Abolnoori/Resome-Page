

<?php $__env->startSection('title' ,  $title ); ?>
<?php $__env->startSection('email' ,  $email ); ?>
<?php $__env->startSection('name' ,  $name ); ?>
<?php $__env->startSection('job-1' , $job1); ?>
<?php $__env->startSection('job-2' , $job2); ?>
<?php $__env->startSection('aboutmy' , $aboutmy); ?>
<?php $__env->startSection('link_resome' , $links['resome']); ?>
<?php $__env->startSection('link_telegram' , $links['telegram']); ?>
<?php $__env->startSection('link_instagram' , $links['instagram']); ?>
<?php $__env->startSection('link_linkedin' , $links['linkedin']); ?>
<?php $__env->startSection('link_github' , $links['github']); ?>

<?php $__env->startSection('counters_hostory' , $counters['hostory']); ?>
<?php $__env->startSection('counters_completion' , $counters['completion']); ?>
<?php $__env->startSection('counters_satisfied' , $counters['satisfied']); ?>
<?php $__env->startSection('counters_experience' , $counters['experience']); ?>


          

                  






<?php echo $__env->make('layout.Master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\NOURI_Abolfazl\Desktop\Resome-Page\resources\views/Home-fa.blade.php ENDPATH**/ ?>