<?php echo $__env->make('layout.Master.Header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="" >
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <span class="modal-title"
                    ><strong>پیام شما با موفقیت ارسال شد</strong></span
                >
                <button
                    type="button"
                    class="close"
                    data-bs-dismiss="modal"
                    aria-label="Close"
                >
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="modal-body">
                <p>
                    از اینکه با ما تماس گرفتید، متشکریم. ما به زودی با شما تماس
                    خواهیم گرفت.<br />روز خوبی داشته باشید!
                </p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn" data-bs-dismiss="modal">
                    بستن
                </button>
            </div>
        </div>
    </div>
</div>

















<?php /**PATH C:\Users\NOURI_Abolfazl\Desktop\Resome-Page\resources\views/sms.blade.php ENDPATH**/ ?>